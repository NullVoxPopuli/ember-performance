declare module '@ember/-internals/utils/lib/lookup-descriptor' {
    export function findDescriptor(obj: object, keyName: string | symbol): {
        object: object;
        descriptor: PropertyDescriptor;
    } | null;
    export default function lookupDescriptor(obj: object, keyName: string | symbol): PropertyDescriptor | null;
}
declare module '@ember/-internals/environment/lib/env' {
    /**
      The hash of environment variables used to control various configuration
      settings. To specify your own or override default settings, add the
      desired properties to a global hash named `EmberENV` (or `ENV` for
      backwards compatibility with earlier versions of Ember). The `EmberENV`
      hash must be created before loading Ember.

      @class EmberENV
      @type Object
      @public
    */
    export const ENV: {
        ENABLE_OPTIONAL_FEATURES: boolean;
        /**
          The `LOG_STACKTRACE_ON_DEPRECATION` property, when true, tells Ember to log
          a full stack trace during deprecation warnings.
      
          @property LOG_STACKTRACE_ON_DEPRECATION
          @type Boolean
          @default true
          @for EmberENV
          @public
        */
        LOG_STACKTRACE_ON_DEPRECATION: boolean;
        /**
          The `LOG_VERSION` property, when true, tells Ember to log versions of all
          dependent libraries in use.
      
          @property LOG_VERSION
          @type Boolean
          @default true
          @for EmberENV
          @public
        */
        LOG_VERSION: boolean;
        /**
          The `LOG_INSPECTOR_HINT` property, when true, tells Ember to log a hint
          suggesting the Ember Inspector browser extension when it is not detected.
      
          @property LOG_INSPECTOR_HINT
          @type Boolean
          @default true
          @for EmberENV
          @public
        */
        LOG_INSPECTOR_HINT: boolean;
        RAISE_ON_DEPRECATION: boolean;
        STRUCTURED_PROFILE: boolean;
        /**
          Whether to perform extra bookkeeping needed to make the `captureRenderTree`
          API work.
      
          This has to be set before the ember JavaScript code is evaluated. This is
          usually done by setting `window.EmberENV = { _DEBUG_RENDER_TREE: true };`
          before the "vendor" `<script>` tag in `index.html`.
      
          Setting the flag after Ember is already loaded will not work correctly. It
          may appear to work somewhat, but fundamentally broken.
      
          This is not intended to be set directly. Ember Inspector will enable the
          flag on behalf of the user as needed.
      
          This flag is always on in development mode.
      
          The flag is off by default in production mode, due to the cost associated
          with the the bookkeeping work.
      
          The expected flow is that Ember Inspector will ask the user to refresh the
          page after enabling the feature. It could also offer a feature where the
          user add some domains to the "always on" list. In either case, Ember
          Inspector will inject the code on the page to set the flag if needed.
      
          @property _DEBUG_RENDER_TREE
          @for EmberENV
          @type Boolean
          @default false
          @private
        */
        _DEBUG_RENDER_TREE: boolean;
        /**
         Whether to force all deprecations to be enabled. This is used internally by
         Ember to enable deprecations in tests. It is not intended to be set in
         projects.
      
         @property _ALL_DEPRECATIONS_ENABLED
         @for EmberENV
         @type Boolean
         @default false
         @private
         */
        _ALL_DEPRECATIONS_ENABLED: boolean;
        /**
         Override the version of ember-source used to determine when deprecations "break".
         This is used internally by Ember to test with deprecated features "removed".
         This is never intended to be set by projects.
         @property _OVERRIDE_DEPRECATION_VERSION
         @for EmberENV
         @type string | null
         @default null
         @private
         */
        _OVERRIDE_DEPRECATION_VERSION: null;
        /**
          Whether the app defaults to using async observers.
      
          This is not intended to be set directly, as the implementation may change in
          the future. Use `@ember/optional-features` instead.
      
          @property _DEFAULT_ASYNC_OBSERVERS
          @for EmberENV
          @type Boolean
          @default false
          @private
        */
        _DEFAULT_ASYNC_OBSERVERS: boolean;
        /**
          Controls the maximum number of scheduled rerenders without "settling". In general,
          applications should not need to modify this environment variable, but please
          open an issue so that we can determine if a better default value is needed.
      
          @property _RERENDER_LOOP_LIMIT
          @for EmberENV
          @type number
          @default 1000
          @private
         */
        _RERENDER_LOOP_LIMIT: number;
        FEATURES: {
            [feature: string]: boolean;
        };
    };
    export function getENV(): object;
}